package com.example.demo.HelloController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.web.bind.annotation.*;

@RestController
public class HelloController {

    @RequestMapping("/hello1")
    public String say1(){
        return "hello";
    }

    @Value("${name}")
    private String name;

    @Value("${age}")
    private Integer age;

    @Value("${content}")
    private String content;

    @RequestMapping(value = "/hello2", method = RequestMethod.GET)
    public String say2(){
        return name;
    }

    @RequestMapping(value = "/hello3", method = RequestMethod.GET)
    public String say3(){
        return content;
    }

    @Autowired
    private StudentProperties studentProperties;
    @RequestMapping(value = "/hello4", method = RequestMethod.GET)
    public String say4(){
        return studentProperties.getName();
    }

    @RequestMapping(value = "/hello5/{id}", method = RequestMethod.GET)
    public String say5(@PathVariable("id") Integer myid){
        return "id = " + myid;
    }

    @RequestMapping(value = "/hello6", method = RequestMethod.GET)
    public String say6(@RequestParam(value = "id", defaultValue = "0", required = false) Integer myid){
        return "id = " + myid;
    }
}
